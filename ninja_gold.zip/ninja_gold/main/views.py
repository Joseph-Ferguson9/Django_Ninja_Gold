from django.shortcuts import render, redirect
import random
from datetime import datetime
from time import strftime

gold_outcomes = {
    'farm': (10,20),
    'cave': (5,10),
    'house': (2,5),
    'casino': (0,50),
}

# Create your views here.
def index(request):
    if not 'gold' in request.session or 'activities' not in request.session:
        request.session['gold'] = 0
        request.session['activities'] = []
    return render(request, 'index.html')

def reset(request):
    request.session.clear()
    return redirect('/')

def process(request):
    if request.method == 'GET':
        return redirect('/')
    building_name = request.POST['find_gold']
    building = gold_outcomes[building_name]
    building_upper = building_name[0].upper() + building_name[1:]
    current_gold = random.randint(building[0], building[1])
    timestamp = datetime.now().strftime("%m/%d/%Y %I:%M%p")
    result = 'earn'
    message = f"Earned {current_gold} from {building_upper}. ({timestamp})"
    if building_name == 'casino':
        if random.randint(0,1) > 0:
            message = f"Entered {building_upper} and lost {current_gold} gold... want an idiot. ({timestamp})"
            current_gold = current_gold * -1
            result = 'lose'
    request.session['gold'] += current_gold
    request.session['activities'].append({'message': message, 'result': result})
    return redirect('/')